<?
$wdcp_name="wdcp";
$wdcp_ver="v2.5.15";///
$wdcp_ver_date="20150826";//
?>