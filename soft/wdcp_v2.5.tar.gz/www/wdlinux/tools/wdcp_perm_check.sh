#!/bin/bash
# wdcp tools
# wdcp perm check
# author wdlinux
# url http://www.wdlinux.cn
/www/wdlinux/wdphp/bin/php /www/wdlinux/wdcp/task/wdcp_perm_check.php
